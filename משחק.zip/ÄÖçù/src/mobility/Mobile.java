package mobility;

public abstract class Mobile implements ILocatable {
	
	/**
	 * A class that implements the location interface. 
	 * Describes location functions and variables
	 */
	
	private Point location;
	private double totalDistance;
	/**
	 * @param totalDistance :Distance the object traveled.
	 * @param location :Current location.
	 */
	
	/**
	 * constructor 
	 * @param location
	 */
	public Mobile(Point location)
	{
		this.location= new Point(location.getX(),location.getY());
		
		this.totalDistance=0;
		
	}
	/**
	 * default constructor. 
	 */
	public Mobile()
	{
		this.location= new Point();
		this.totalDistance=0;
	}
	/**
	 * increases total distance after movement
	 * @param d : distance double
	 */
	protected void addTotalDistance(double d)
	{
		this.totalDistance+=d;
	}
	/**
	 * 
	 * @param p Point
	 * @return returns distance traveled (0 if non)
	 */
	protected double move(Point p)
	{
		if(this.location==p)
			return 0;
		double d=this.calcDistance(p);
		this.location= new Point(p.getX(),p.getY());
		this.addTotalDistance(d);
		return d;
	}
	/**
	 * 
	 * @param other Point
	 * @return Distance between object to the point 
	 */
	public double calcDistance(Point other)
	{
		int x1=this.location.getX();
		int y1=this.location.getY();
		int x2=other.getX();
		int y2=other.getY();
		
		return Math.sqrt((Math.pow(x1-x2, 2)+Math.pow(y1-y2, 2)));
	}
	/**
	 * @return current location
	 */
	public Point getLocation() 
	{
		return this.location;
	}
	/**
	 * setting location.
	 */
	public boolean setLocation(Point p) 
	{
		if(p.setX(p.getX()) && p.setY(p.getY()))
			return true;
		return false;
	}
	/**
	 * @return representation of this Class.
	 */
	public String toString()
	{
		return "Location:"+this.getLocation()+"\nthe Total-Distance is: "+this.totalDistance;
	}
	public double getTotalDistance() {return this.totalDistance;}
	

}
