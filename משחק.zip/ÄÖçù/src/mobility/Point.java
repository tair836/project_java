package mobility;

public class Point {
	private int x;
	private int y;
	/**
	 * 
	 * @param x
	 * @param y
	 */
	
	/**
	 * constructor
	 * @param x
	 * @param y
	 */
	public Point(int x,int y)
	{
		this.x= (x>=0) ?x:0;
		this.y= (y>=0) ?y:0;
	}
	/**
	 * default constructor.
	 */
	public Point()
	{
		this.x=0;
		this.y=0;
	}
	/**
	 * 
	 * @return x
	 */
	public int getX() {return this.x;}
	/**
	 * 
	 * @return y
	 */
	public int getY() {return this.y;}
	/**
	 * 
	 * @param x
	 * @return Success of placement.
	 */
	public boolean setX(int x)
	{
		if(x>=0)
		{
			this.x=x;
			return true;
			}
		return false;
	}
	/**
	 * 
	 * @param y
	 * @return Success of placement.
	 */
	public boolean setY(int y)
	{
		if(y>=0) {
			this.y=y;
			return true;
		}
		return false;
	}
	/**
	 * @return representation of this Class.
	 */
	public String toString() {
		
		return "("+x+","+y+")";
		
	}
	/**
	 * 
	 * @param p Point
	 * @return if object equal to other point.
	 */
	public boolean equals(Point p) {
		return (this.x==p.x && this.y==p.y);
	}

}
