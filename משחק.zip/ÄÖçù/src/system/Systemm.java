package system;
/*mport animals.*;
import animals.Animal.Gender;
import mobility.*;
import olympics.Medal;
import olympics.MedalType;

import java.util.*;
/**
 * 
 * @author Tair_Shriki_211966379
 * @author Shaked_Levi_318816329
 *
 */

/*public class Systemm {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter please amount of animals you want: ");
		int numOfAnimals=input.nextInt(); 
		Animal[] zoo=new Animal[numOfAnimals];
		for(int i=0;i<numOfAnimals;++i)
		{
		createAnimal(zoo,i);
		}
		menu(zoo);
		
	}

	public static void createAnimal(Animal [] zoo,int i) {

		String name;
		Scanner input2=new Scanner(System.in);
		System.out.println("Enter please details of animal "+(i+1)+":");

		System.out.print("name: ");
		name=input2.next();

		System.out.print("gender: 1.Male 2.Female 3.Hermaphrodite: "); Gender g=gender(input2.nextInt());
		System.out.print("weight: "); double weight=input2.nextDouble();
		System.out.print("speed: "); double speed=input2.nextDouble();
		System.out.print("Enter number of medals' animal: ");
		Medal [] m=createArrMedal(input2.nextInt());
		System.out.print("Position(x,y): ");
		System.out.print("x: "); int x=input2.nextInt();
		System.out.print("y: "); int y=input2.nextInt();
		Point p=new Point(x,y);

		System.out.println("Enter please type of animal "+(i+1)+":");
		System.out.print("1.AirAnimal 2.WaterAnimal 3.TerrestrialAnimals: "); int choose=input2.nextInt();
		
		switch(choose) {
		case 1:
		AirAnimals(zoo,i,p,name,g,weight,speed,m);
		break;
		case 2:
		WaterAnimals(zoo,i,p,name,g,weight,speed,m);
		break;
		case 3:
		TerrestrialAnimals(zoo,i,p,name,g,weight,speed,m);
		break;

		}
	}
		
	private static void TerrestrialAnimals(Animal[] zoo, int i, Point p, String name, Gender g, double weight,double speed, Medal[] m) 
	{
		Scanner input4=new Scanner(System.in);
		System.out.print("noLegs: "); int noLegs=input4.nextInt();
		System.out.print("Enter please kind of animal: ");
		System.out.print("1.Dog 2.Cat 3.Snake: "); int choose=input4.nextInt();
		switch(choose) {
		case 1:
		System.out.print("breed: "); String breed=input4.next();
		zoo[i]=new Dog(breed,noLegs,name,g,weight,speed,m,p);
		break;
		case 2:
		System.out.print("castrated: "); boolean castrated=input4.nextBoolean();
		zoo[i]= new Cat(castrated,noLegs,name,g,weight,speed,m,p);
		break;
		case 3:
		System.out.println("poisonous: ");
		System.out.print("1.High 2.Medium 3.Low: "); Poisonous po=posionous(input4.nextInt());
		System.out.print("length: "); double length=input4.nextInt();
		zoo[i]= new Snake(po,length,noLegs,name,g,weight,speed,m,p);
		break;
		default:
		System.out.print("1.Dog 2.Cat 3.Snake: ");
		choose=input4.nextInt();
		break;
		}
	}

	private static void AirAnimals(Animal[] zoo, int i, Point p, String name, Gender g, double weight, double speed,Medal[] m) {
		Scanner input3=new Scanner(System.in);
		System.out.print("wingspan : "); double wingspan=input3.nextDouble();
		System.out.print("Enter please kind of animal: ");
		System.out.print("1.Eagle 2.Pigeon: "); int choose=input3.nextInt();
		switch(choose) {
		case 1:
		System.out.print("altitudeOfFlight: "); double altitudeOfFlight=input3.nextDouble();
		zoo[i]= new Eagle(altitudeOfFlight,wingspan,name,g,weight,speed,m,p);
		break;
		case 2:
		System.out.print("family: "); String family=input3.next();
		zoo[i]= new Pigeon(family,wingspan,name,g,weight,speed,m,p);
		break;
		default:
		System.out.print("1.Eagle 2.Pigeon: "); choose=input3.nextInt();
		break;

		}
	}

	private static void WaterAnimals(Animal [] zoo,int i, Point p,String name,  Gender g, double weight, double speed, Medal[] m) {
		Scanner input1=new Scanner(System.in);
		double diveDept;
		System.out.print("diveDept: "); diveDept=input1.nextDouble();
		System.out.println("Enter please kind of animal: ");
		System.out.println("1.Alligator 2.Whale 3.Dolphin: "); int choose=input1.nextInt();

		switch(choose) {
		case 1:
		System.out.print("AreaOfLiving: "); String area=input1.next();
		//zoo[i]= new Alligator(area,diveDept,name,g,weight,speed, m,p);
		break;
		case 2:
		System.out.print("FoodType: "); String foodType=input1.next();
		zoo[i]= new Whale(foodType,diveDept,name, g, weight, speed,m, p);
		break;
		case 3:
		System.out.print("water type: ");
		System.out.print("1.sweet 2.sea: "); WaterType wt=waterType(input1.nextInt());
		zoo[i]=new Dolphin(wt,diveDept,name,g,weight,speed,m,p);
		break;
		default:
		System.out.print("1.Alligator 2.Whale 3.Dolphin: ");
		choose=input1.nextInt();
		break;
		}
	}

	public static Gender gender(int choose)
	{
		switch(choose)
		{
		case 1:
		return Gender.Male;
		case 2:
		return Gender.Female;
		case 3:default:
		return Gender.Hermaphrodite;
		}
	}
		 
	public static WaterType waterType(int choose)
	{
		switch(choose)
		{
		case 1:
		return WaterType.Sweet;
		case 2:
		return WaterType.Sea;
		default:
		return WaterType.Sea;
		}
	}

	public static Poisonous posionous(int choose)
	{
		switch(choose)
		{
		case 1:
		return Poisonous.High;
		case 2:
		return Poisonous.Medium;
		case 3:
		return Poisonous.Low;
		default:
		return Poisonous.Medium;
		}
	}

	public static Medal[] createArrMedal(int size)
	{
		Medal []m=new Medal[size];
		for(int i=0;i<size;++i)
		{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter details of medal "+(i+1)+": ");
		System.out.println("type: ");
		System.out.print("1.BRONZE 2.SILVER 3.GOLD: "); int choose=input.nextInt();
		MedalType t;
		
		switch(choose)
		{
		case 1:
		t=MedalType.BRONZE;
		break;
		case 2:
		t= MedalType.SILVER;
		break;
		case 3:
		t=MedalType.GOLD;
		break;
		default:
		t=MedalType.BRONZE;
		break;
		}
		System.out.print("year: "); int year=input.nextInt();
		System.out.print("tournament: ");  String tournament=input.next();
		m[i]=new Medal(t,tournament,year);
		}
		return m; 
	}

	public static void menu(Animal [] zoo)
		{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter 1: See the information about the animals\nEnter 2: Sound's animals\nEnter 3:Exit");
		int choose=input.nextInt();
	while(choose!=3) {
		switch (choose) {
		case 1:
		for (int i=0;i<zoo.length;++i) {
		System.out.println(zoo[i].toString());
		}
		System.out.println("Enter 1: See the information about the animals\nEnter 2: Sound's animals\nEnter 3:Exit");
		 choose=input.nextInt();
		break;
		case 2:
		for(int i=0;i<zoo.length;++i) {
		zoo[i].makeSound();
		}
		System.out.println("Enter 1: See the information about the animals\nEnter 2: Sound's animals\nEnter 3:Exit");
		choose=input.nextInt();
		break;
		
		default:
		System.out.println("Please enter again"); choose=input.nextInt();//input.close();
		break;
		}
	}
			System.out.println("Goodbye");
		

		}}
*/
