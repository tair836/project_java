package tournament;
import animals.Animal;

public class RegularTournament extends Tournament{

	/**
	 * cons
	 * @param a
	 * @param mane_group
	 * @param dis
	 * @param startFlag
	 * @param scores
	 */
	public RegularTournament(Animal[][] a,String mane_group,int dis,Boolean startFlag,Scores scores) {
		super(a,mane_group,dis,startFlag,scores);
	}
	/**
	 * define type of competition.
	 */

	@Override
	protected void setup(Animal[][] a,String mane_group,int dis,Boolean startFlag,Scores scores) {
		Boolean finishFlag =new Boolean(false);
		startFlag= new Boolean(false);
		new AnimalThread(startFlag,finishFlag);
		
		Referee.getInstance(mane_group,scores,finishFlag);
		super.tourname.setScores(scores);
		super.tourname.setstartSignal(startFlag);		
	}
}
