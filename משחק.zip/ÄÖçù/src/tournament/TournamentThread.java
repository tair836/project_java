package tournament;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import graphics.CompetitionFrame;


public class TournamentThread implements Runnable {

	
	private Scores scores;//Final results of each group
	private Boolean  startSignal;//A special flag that starts all the animals.
	private int group;//The number of groups that compete
	
	public TournamentThread() {
		
		HashMap<String,Date> s =new HashMap<String,Date> ();
		scores=new Scores(s);
		
		startSignal= new Boolean(false);
	}
	
	
	
	public void  setScores(Scores scores) {
		
		if(scores!=null)
			this.scores=scores;	
	}
	
	public void  setstartSignal(Boolean  startSignal) {
		
		this.startSignal=startSignal;
	}
	
	public void setGroup(int group) {
		
		this.group=group;
		
	}
	
	
	
	@Override
	public void run() {
		
		Info();
		
		synchronized(this.startSignal) {
			while (this.startSignal.equals(true))
				notifyAll();
				
		}
		
		//notifyAll();
		
//		JFrame frame=new JFrame("Groups Information");
//		JTable infoo=new JTable();
//		String[] name_groups= {"Group1","Group2","Group3"};//rows
//		Date [][]data = new Date[1][3];
//		
//		int k=0;
//		for(Date d : this.scores.scores.values()) {
//			if(d!=null)
//				data[0][k]=d;
//			k++;
//		}
//		
//		
//		infoo = new JTable(data, name_groups); 
//		JScrollPane sp = new JScrollPane(infoo); 
//        frame.add(sp); 
//        frame.setSize(900, 200); 
//        frame.setVisible(true); 	
		

	}	
	public  void Info() {
		
		scores.add("aa");
		scores.add("aa");
		scores.add("aa");


		
		JFrame frame=new JFrame("Groups Information");
		JTable infoo=new JTable();
		String[] name_groups= {"Group1","Group2","Group3"};//rows
		Date [][]data = new Date[1][3];
		
		int k=0;
		Map<String, Date> s= scores.getAll();
		for(Date d : s.values()) {
			if(d!=null)
				data[0][k]=d;
			k++;
		}
		
		
		infoo = new JTable(data, name_groups); 
		JScrollPane sp = new JScrollPane(infoo); 
        frame.add(sp); 
        frame.setSize(900, 200); 
        frame.setVisible(true); 	
		
	}
}