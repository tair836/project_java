package tournament;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Scores {
	
	Map<String,Date> scores;//A queue of scores. <Name of the group, time>
	
	/**
	 * Constructor
	 * @param s map of scores.
	 */
	public Scores(HashMap<String,Date> s) {

		scores= s; 
		scores=Collections.synchronizedMap(scores);
	}
	
	/**
	 * add name of group and add to the queue.
	 * @param name
	 */
	public void add(String name) {
		
		scores.put(name, new Date());
		
	}
	/**
	 * 
	 * @return scores
	 */
	 public Map<String, Date> getAll(){
		 return scores;
		 }

}
