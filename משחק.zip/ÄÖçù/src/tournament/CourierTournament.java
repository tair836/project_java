package tournament;
import animals.Animal;


public class CourierTournament extends Tournament{
	/**
	 * constructor
	 * @param a
	 * @param name_group
	 * @param dis
	 * @param startFlag
	 * @param scores
	 */

	public CourierTournament(Animal[][] a,String name_group,int dis,Boolean startFlag,Scores scores) {
		super(a,name_group,dis,startFlag,scores);
		}

	/**
	 * define type of competition.
	 */
	@Override
	protected void setup(Animal[][] a,String name_group,int dis,Boolean startFlag,Scores scores) {
		
		startFlag.setBoolean(false);
		Boolean finishFlag =new Boolean(false);
		
		AnimalThread [][]at=new AnimalThread[a.length][4];
		
		for(int j=0;j<a.length;++j) {//num of competition
		
			at[j][0]= new AnimalThread(a[j][0],finishFlag ,startFlag,dis/a[j].length);
			Boolean[] b=new Boolean[a[j].length];
			
			for(int i=1;i<a[j].length;++i) {//num of animal in specific competition.
				
				for (int k=0;k<a[j].length;++k)
					b[k]=new Boolean(false);
				
				startFlag=at[j][i-1].startFlag;
				
				at[j][i]= new AnimalThread(a[j][i],startFlag,b[i],dis/a[j].length);								
			}
			Referee.getInstance(name_group,scores,finishFlag);
			super.tourname.setGroup(a[j].length);
			super.tourname.setScores(scores);
			super.tourname.setstartSignal(startFlag);

		}	
	}
}
