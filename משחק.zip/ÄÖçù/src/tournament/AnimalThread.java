package tournament;
import animals.Animal;

public class AnimalThread implements Runnable {
	
	Animal participant;//The animal we are promoting.
	double neededDistance;//The distance required to go from start to finish.
	Boolean startFlag ;// starting position.
	Boolean finishFlag;//Final state.
	static int numOfSleep;//Thread.sleep(numOfSleep).
	
	/**
	 * constructor
	 * @param participant
	 * @param numOfSleep
	 * @param neededDistance
	 */
	
	public AnimalThread(Animal participant,int numOfSleep,double neededDistance) {
		this.participant= participant;
		AnimalThread.numOfSleep=numOfSleep;
		this.neededDistance= neededDistance;
		startFlag =new  Boolean(false);
		finishFlag=new  Boolean(false);
	}
	
	/**
	 * Constructor
	 * @param startFlag
	 * @param finishFlag
	 */

	public AnimalThread(Boolean startFlag,Boolean finishFlag) {//from class RegularTournament
		
		this.finishFlag = finishFlag;
		this.startFlag = startFlag;	
	}
	
	/**
	 * Constructor
	 * @param animal
	 * @param startFlag
	 * @param finishFlag
	 * @param d  
	 */
	
	public AnimalThread(Animal animal, Boolean startFlag, Boolean finishFlag, int d) {
	
		this.participant=animal;
		this.finishFlag = finishFlag;
		this.startFlag = startFlag;
		this.neededDistance=d;		
	}

	@Override
	public void run() {
		
		synchronized(this.startFlag) {
			while (this.startFlag.equals(false))
			
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}
		Thread.interrupted();
		
		try {
			Thread.sleep(numOfSleep);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
}
