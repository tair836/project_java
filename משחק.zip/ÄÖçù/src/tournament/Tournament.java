package tournament;
import animals.Animal;
import tournament.Boolean;


public abstract class Tournament {
	
	protected TournamentThread tourname;
	
	/**
	 * cons
	 * @param a
	 * @param mane_group
	 * @param dis
	 * @param startFlag
	 * @param scores
	 */
	
	public Tournament(Animal[][] a,String mane_group,int dis,Boolean startFlag,Scores scores) {
		
		tourname=new TournamentThread();
		tourname.setGroup(a.length);
		tourname.setScores(scores);
		tourname.setstartSignal(startFlag);
	
		setup(a,mane_group, dis,startFlag,scores);
	}
	
	public TournamentThread getTournamentThread() {return tourname;}
	
	/**
	 * define type of competition.
	 * abstract method
	 * @param a
	 * @param mane_group
	 * @param dis
	 * @param startFlag
	 * @param scores
	 */
	
	protected abstract void setup(Animal[][] a,String mane_group,int dis,Boolean startFlag,Scores scores);
}
