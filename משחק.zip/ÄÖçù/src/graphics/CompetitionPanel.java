package graphics;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import tournament.*;
import tournament.Boolean;

/**
 * 
 * @author Shaked Levi 318816329
 * @author Tair Shriki 211966379
 *
 */

public class CompetitionPanel extends JPanel implements ActionListener {
	

	
	 public static BufferedImage image,over,over1,over2,over3;
	 private JPanel panel;
	//private BufferedImage combined;		
	 Graphics g=null;
	 String[] op= new String[5];
	   String l=null,n; 
	   JButton btn,button1,button2,button3,button4,button5,button6;
	   Tournament tournament;
	   
		public CompetitionPanel() {
			
			HashMap<String,Date> s =new HashMap<String,Date> ();
			CompetitionFrame.scores= new Scores(s);
			
			
			panel=new JPanel();
			
			button1=new JButton("Competiton");
			button2=new JButton("Add Animal");
			button3=new JButton("Clear");
			button4=new JButton("Eat");
			button5=new JButton("Info");
			button6=new JButton("Exit");
			panel.add(button1);
			panel.add(button2);
			panel.add(button3);
			panel.add(button4);
			panel.add(button5);
			panel.add(button6);
			
			this.setLayout(new BorderLayout());
			this.add(panel,BorderLayout.SOUTH);
			button1.addActionListener(this);
			button1.setPreferredSize(new Dimension(160, 40));
			button2.addActionListener(this);
			button2.setPreferredSize(new Dimension(160, 40));
			button3.addActionListener(this);
			button3.setPreferredSize(new Dimension(160, 40));
			button4.addActionListener(this);
			button4.setPreferredSize(new Dimension(160, 40));
			button5.addActionListener(this);
			button5.setPreferredSize(new Dimension(160, 40));
			button6.addActionListener(this);
			button6.setPreferredSize(new Dimension(160, 40));
			
			repaint();
		}

		public void actionPerformed(ActionEvent arg0) {
		
			String choose=arg0.getActionCommand();
			
			String d1=null;
			String choice_ani = null;
		
			
	if(choose.contentEquals("Exit")) 

	   System.exit(0); 

	  
	else if(choose.contentEquals("Info")) {

		CompetitionFrame.tair_shaked.run();
	
	
	}



//case "Competition":
	else if(choose.contentEquals("Competiton")) {
	 setFont(new Font("Arial Black", Font.PLAIN, 20));////////font
	
	String[] options = {"Air", "Terrestrial", "Water"};
	String[] options1 = {"Courier", "Regular"};
    UIManager.put("OptionPane.messageFont", getFont());//////////////font

	UIManager.put("OptionPane.minimumSize",new Dimension(400,200)); 
     l = (String)JOptionPane.showInputDialog(null, "Type of new tournament:",null,
    		JOptionPane.QUESTION_MESSAGE, null, options1, options1[0]);
    if(l==null) {
    	l= "Regular";
    	//tournament=new RegularTournament(CompetitionFrame.ani_arr,("Group"+String.valueOf(CompetitionFrame.i+1)), 1000, new Boolean(false), CompetitionFrame.scores);
    }
    else if(l.equals("Courier")) {
    	l="Courier";
    	tournament=new CourierTournament(CompetitionFrame.ani_arr,("Group"+String.valueOf(CompetitionFrame.i+1)), 1000, new Boolean(false), CompetitionFrame.scores);
    }
    
	UIManager.put("OptionPane.minimumSize",new Dimension(400,200)); 
    n = (String)JOptionPane.showInputDialog(null, "Type of new competition:",null,
    		JOptionPane.QUESTION_MESSAGE, null,options, options[0]);
  
}
	else if(choose.contentEquals("Add Animal")) {
		if (n==null) {
			setFont(new Font("Arial", Font.PLAIN, 20));///////////font
		 UIManager.put("OptionPane.messageFont", getFont());////////font
		UIManager.put("OptionPane.minimumSize", new Dimension(400, 150));
			JOptionPane.showMessageDialog(null, "Uh-oh!\nNo competition was selected", "Error", JOptionPane.ERROR_MESSAGE);
		}
	else {
    AddAnimalDialog d= new AddAnimalDialog();
    
    AnimalThread ani=new AnimalThread(CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j],200,10);
    
	Thread t= new Thread((Runnable)(ani));
	tournament=new RegularTournament(CompetitionFrame.ani_arr,("Group"+String.valueOf(CompetitionFrame.i+1)), 1000, new Boolean(false), CompetitionFrame.scores);
	t.start();
	
	if(l.equals("Regular"))
		CompetitionFrame.regular = true;
	d.AddAnimalDialog1(n);
	}
	
}

   


	
	
	else if(choose.contentEquals("Eat"))  {
	
	UIManager.put("OptionPane.minimumSize", new Dimension(400, 150));
	 choice_ani = (String)JOptionPane.showInputDialog(null, "choose an animal:",null,
    		JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
	 String eng_input = JOptionPane.showInputDialog("Enter energy: ");
	int add= Integer.parseInt(eng_input);
	 for(int i=0;i<3;++i) 
		 for(int j=0;j<4;++j) {
			 if(choice_ani.equals(CompetitionFrame.ani_arr[i][j].getName())) {
				 //ani_arr[i][j].eat(Integer.parseInt(eng_input));	
				 
				 
				 break;
		}
		 }
}
	 
 
	else if(choose.contentEquals("Clear")) {
	setFont(new Font("Arial", Font.PLAIN, 20));///////////font
	 UIManager.put("OptionPane.messageFont", getFont());////////font
	UIManager.put("OptionPane.minimumSize", new Dimension(400, 150));
	choice_ani = (String)JOptionPane.showInputDialog(null, "choose an animal to delete:",null,
    		JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
	//Repaint without this image: choice_ani(name of ani)
	
	
}	
}
  
		  
	    public void paintComponent(Graphics g) {
	    	super.paintComponent(g);		
	    	  try{image = ImageIO.read(new File("competitionBackground.png"));}
  	    catch (IOException e){System.out.println("Cannot load image1");}
	    	  //g.drawImage(image, 0, 0, null);
			 g.drawImage(image, 0,0,this.getWidth(),this.getHeight(),this);
			
			for(int i=0;i<3;i++)
				for(int j=0;j<3;j++) {
					//System.out.println(CompetitionFrame.i+" "+CompetitionFrame.j);
					if(CompetitionFrame.ani_arr[i][j]!=null)
						CompetitionFrame.ani_arr[i][j].drawObject(g);	
				}
		
				this.repaint();
			}

}
