package graphics;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.*;
import java.util.Date;
import java.util.HashMap;

import javax.swing.*;
import animals.*;
import tournament.Scores;
import tournament.TournamentThread;

/**
 * 
 * @author TAir Shriki 211966379
 * @author Shaked Levi 318816329
 *
 */
public class CompetitionFrame extends JFrame implements ActionListener{

	 private String[] name_button= {"Competition","Add Animal","Clear","Eat","Info","Exit"};
	 JFrame frame;
	 String n,l;
	private Animal animal;
	//public static int leni=2,lenj=3;
	public static  Animal[][] ani_arr = new Animal[3][3];
	public static int i=0,j=0;
	String[] op= new String[5];
	static boolean regular = false;
	 CompetitionPanel p;
	 public static TournamentThread tair_shaked= new TournamentThread();
	 //HashMap<String,Date> s =new HashMap<String,Date> ();
	public static Scores scores= new Scores(new HashMap<String,Date> ());
public CompetitionFrame() 
{

	JMenuBar menuBar;
    JMenu menu;
    JMenuItem menuItem;
    frame= new JFrame("Competition");

    //Create the menu bar.
    menuBar = new JMenuBar();

    //Build the first menu.
    menu = new JMenu("File");
    menu.setMnemonic(KeyEvent.VK_A);
    menuBar.add(menu);

    //a group of JMenuItems
    menuItem = new JMenuItem("Exit",KeyEvent.VK_T);
    menu.add(menuItem);
    menuItem.addActionListener(this);

    //Build second menu in the menu bar.
    menu = new JMenu("Help");
    menuItem = new JMenuItem("Help",KeyEvent.VK_T);
    menu.add(menuItem);
    menu.setMnemonic(KeyEvent.VK_N);
    menuItem.addActionListener(this);
    menuBar.add(menu);
   
    
   ////////////////////////////////////////////
   

    frame.setJMenuBar(menuBar);
   
    p=new CompetitionPanel();
    p.setBounds(0, 0, 1200, 1020);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setSize(1200, 1020);
	frame.add(p);
	frame.setVisible(true);
	

}



public void actionPerformed(ActionEvent arg0) {
	String choose=arg0.getActionCommand();
	String d1=null;
	String choice_ani = null;
	
	
	switch(choose)
	{
	case "Exit": System.exit(0); break;
	case "Help":
		Font font = new Font("Arial", Font.PLAIN, 20);
		 UIManager.put("OptionPane.messageFont", font);
		UIManager.put("OptionPane.minimumSize",new Dimension(400,200)); 
	JOptionPane.showMessageDialog(frame,"Home Work 2\nGUI","Message", JOptionPane.INFORMATION_MESSAGE);
	break;
	}
}
	

 

public static void main(String[] args)   {

	new CompetitionFrame();
	

}




}