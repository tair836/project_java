package animals;
import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public class Dog extends TerrestrialAnimals {
	
	private String breed ;
	/**
	 * default constructor
	 */
	public Dog()
	{
		super();
		breed=null;
	}
	/**
	 * constructor
	 * @param breed
	 * @param noLegs
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Dog(String breed,int noLegs,String name,Gender g,double weight,double speed,Point location,int num) 
	{
		super(noLegs,name,g,weight,speed,location,num);
		this.breed=breed;
	}
	@Override
	public String talk() {return "Woof Woof";}
	 
	public String toString() {
		return super.toString()+"\n"+"Breed: "+this.breed+"\n";
	}
	public String getType() {return "Dog";}
}
