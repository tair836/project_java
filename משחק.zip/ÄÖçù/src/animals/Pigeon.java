package animals;

import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public class Pigeon extends AirAnimal {
	
	private String family;
	/**
	 * default constructor
	 */
	public Pigeon()
	{
		super();
		family=null;
	}
	/**
	 * constructor
	 * @param family
	 * @param wingspan
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Pigeon(String family,double wingspan,String name,Gender g,double weight,double speed,Point location,int num)
	{
		super(wingspan,name,g,weight,speed,location,num);
		this.family=family;
	}
	
	@Override
	public String talk() {return "Arr-rar-rar-rar-raah";}
	
	public String toString() {
		return super.toString()+"\n"+"Family: "+this.family+"\n";
	}
	public String getType() {return "Pigeon";}
}
