package animals;

import mobility.*;
import olympics.Medal;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import animals.*;
import animals.Animal.Gender;

public abstract class WaterAnimal  extends Animal{
	
	private static final double MAX_DIVE = -800 ;
	private double diveDept ;//dive deeper
	/**
	 * default constructor
	 */
	public WaterAnimal() 
	{
		super(null,Gender.Hermaphrodite,0,0,new Point(50,0),1);
		diveDept=0;
	}
	/**
	 * 
	 * constructor
	 * 
	 * @param divDept
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g gender
	 */
	public WaterAnimal(double divDept,String name,Gender g,double weight,double speed,Point location,int num) {
		super(name,g,weight,speed,location,num);
		this.diveDept=divDept;
		loadImages(name) ;
	}
	/**
	 * 
	 * @param x
	 * @return make the animal dive deeper, however,
	 *  only it doesn't cause it to dive deeper than its MAX_DIVE value
	 */
	public double Dive(double x)
	{
		return Math.min(MAX_DIVE, this.diveDept+=x);
	}
	public String toString() {
		return super.toString()+"\n"+"DiveDept: "+this.diveDept;
	}
	public String getCategory() {return "Water";}
	
	public void loadImages(String nm) {
		try {
		img1= ImageIO.read(new File(nm + "E.png"));
		img2= ImageIO.read(new File(nm + "W.png"));
	}
	catch (IOException e) { System.out.println("Cannot water load image"); }
		
	}


}
