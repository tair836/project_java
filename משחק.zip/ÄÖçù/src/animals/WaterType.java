package animals;

public enum WaterType {
	
	Sea, Sweet

}
