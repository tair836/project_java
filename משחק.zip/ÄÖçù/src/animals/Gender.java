package animals;

public enum Gender {
	
	Male,Female,Hermaphrodite

}
