package animals;

import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public class Dolphin extends WaterAnimal{
	
	private WaterType water;
	/**
	 * default constructor
	 */
	public Dolphin() 
	{
		super();
		this.water=WaterType.Sea;
	}
	/**
	 * constructor
	 * @param water
	 * @param divDept
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Dolphin(WaterType water,double divDept,String name,Gender g,double weight,double speed,Point location,int num) 
	{
		super(divDept,name,g,weight,speed,location,num);
		this.water=water;
	}
	
	@Override
	public String talk() {return "Click-click";}
	
	public String toString() {
		return super.toString()+"\n"+"WaterType: "+this.water+"\n";
	}
	public String getType() {return "Dolphin";}
}
