package animals;

public enum Poisonous {

	High,Medium,Low
}
