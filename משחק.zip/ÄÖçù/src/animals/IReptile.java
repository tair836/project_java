package animals;

public interface IReptile {

	public static final  double MAX_SPEED =5;
	/**
	 * make the reptile crawls faster,however,only it doesn't make it crawls faster than the MAX_SPEED value
	 * @param x
	 */
	void speedUp(int x); 
}
