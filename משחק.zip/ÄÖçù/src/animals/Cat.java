package animals;

import java.awt.Image;

import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public class Cat extends TerrestrialAnimals {
	
	private boolean Castrated;
	/**
	 * default constructor
	 */
	public Cat()
	{
		super();
		Castrated=false;
	}
	/**
	 * constructor
	 * @param castrated
	 * @param noLegs
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Cat(boolean castrated,int noLegs,String name,Gender g,double weight,double speed,Point location,int num)
	
	{
		super(noLegs,name,g,weight,speed,location,num);
		this.Castrated=castrated;
	}
	@Override
	public String talk() {return "Meow";}

	public String toString() {
		return super.toString()+"\n"+ "Castrated:"+this.Castrated+"\n";
	}
	public String getType() {return "Cat";}

}
