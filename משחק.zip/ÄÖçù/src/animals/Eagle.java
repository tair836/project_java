package animals;

import animals.Animal.Gender;
import mobility.*;
import olympics.Medal;
public class Eagle extends AirAnimal {
	static final double  MAX_ALTITUDE =  1000;
	private double	altitudeOfFlight;
	
	/**
	 * default constructor
	 */
	 public Eagle()
	 {
		 super();
		 this.altitudeOfFlight=0;
	 }
	 /**
	  * constructor
	  * @param alt
	  * @param wingspan
	  * @param location
	  * @param name
	  * @param weight
	  * @param speed
	  * @param g
	  */
	 public Eagle(double alt,double wingspan,String name,Gender g,double weight,double speed,Point location,int num)
	 {
		 super(wingspan,name,g,weight,speed,location,num);
		 Math.min(MAX_ALTITUDE,this.altitudeOfFlight+=alt);
		
	 }

	@Override
	public String talk() {return "Clack-wack-chack";}
	
	public String toString() {
		return super.toString()+"\n"+"AltitudeOfFlight: "+this.altitudeOfFlight+"\n";
	}
	public String getType() {return "Eagle";}
}
