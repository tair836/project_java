package animals;

import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public class Whale extends WaterAnimal{
	
	private String foodType;
	/**
	 * default contractors
	 */
	public Whale() 
	{
		super();
		foodType=null;
	}
	/**
	 * constructor
	 * @param food
	 * @param divDept
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Whale(String food,double divDept,String name,Gender g,double weight,double speed,Point location,int num)
	{
		super(divDept,name,g,weight,speed,location,num);
		this.foodType=food;
	}
	
	@Override
	public String talk() {return "Splash";}
	
	public String toString() {
		return super.toString( )+ "\n"+"FoodType: "+this.foodType+"\n";
	}
	public String getType() {return "Whale";}
}
