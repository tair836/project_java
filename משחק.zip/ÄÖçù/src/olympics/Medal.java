package olympics;

public class Medal {
	/**
	 * 
	 * @author Tair_Shriki_211966379__Shaked_levi_318816329
	 *
	 */
		
		private MedalType type;
		private String tournament;
		private int year;
		/**
		 * @param type: type of medal
		 * @param tournament: Which tournament won the medal
		 * @param year: Which year he won the medal
		 */
		/**
		 * constructor.
		 * @param tournament
		 * @param year
		 * @param type
		 */
		public Medal(MedalType type,String tournament,int year) 
		{
			this.tournament=tournament;
			this.year=(year>0)? year:2020;
			this.type=type;
			
		}
		/**
		 * default constructor.
		 */
		public Medal()
		{
			this.type=MedalType.BRONZE;
			this.tournament="Art";
			this.year=2020;
			
		}
		/**
		 * @return representation of this Class.
		 */
		public String toString()
		{
			return "type: "+this.type+"	Tournament: "+this.tournament+"	in: "+this.year+"\n";
		}

}
