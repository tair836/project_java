package animals;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public  class TerrestrialAnimals extends Animal {
	
private int noLegs;//legs' number
	
	/**
	 * default constructor
	 */
	public TerrestrialAnimals() 
	{
		super(null,Gender.Hermaphrodite,0,0,new Point(0,20),1);
		noLegs=0;
	}
	/**
	 * constructor
	 * 
	 * @param noLegs
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g gender
	 */
	public TerrestrialAnimals(int noLegs,String name,Gender g,double weight,double speed,Point location,int num)
	{
		super(name,g,weight,speed,location,num);
		this.noLegs=noLegs;
		loadImages(name) ;
	}
	public String toString() {
		return super.toString()+"\n"+"NoLegs: "+this.noLegs;
	}

	public String getCategory() {return "Terrestrial";}
	@Override
	public String talk() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}
	public void loadImages(String nm)  {
		try {
		img1= ImageIO.read(new File(nm + "E.png"));
		img2= ImageIO.read(new File(nm + "S.png"));
		img3= ImageIO.read(new File(nm + "W.png"));
		img4= ImageIO.read(new File(nm + "N.png"));
		}
		catch (IOException e) { System.out.println("Cannot terrestrial load image"); }
	}
		
		

		
	}
	

	


