package animals;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import mobility.*;

public abstract class AirAnimal extends Animal{
	
	private double wingspan;
	/**
	 * default constructor
	 */
	public AirAnimal() 
	{
		super(null,Gender.Hermaphrodite,0,0,new Point(0,100),1);
		this.wingspan=0;
	}
	/**
	 * 
	 * constructor
	 * 
	 * @param wingspan
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g gender
	 */
	public AirAnimal(double wingspan,String name,Gender g,double weight,double speed,Point location,int num)
	{
		super(name,g,weight,speed,location,num);
		this.wingspan=wingspan;
			loadImages(name);
		
	}
	public String toString() {
		return super.toString()+"\n"+"the wingspan: "+this.wingspan;
	}
	public String getCategory() {return "Air";}

	public void loadImages(String nm) 
{
		try {

		img1= ImageIO.read(new File(nm + ".png"));	
	}
	catch (IOException e) { System.out.println("Cannot air load image"); }
	}
}
