package animals;


import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Timer;

import graphics.CompetitionPanel;
import graphics.IAnimal;
import mobility.Mobile;
import mobility.Point;
import olympics.Medal;

public abstract class Animal extends Mobile implements IAnimal{ /*implements   IDrawable, IClonable, ImageObserver{//ILocable, */
	
	private String	name ;//animal's name 
	public enum Gender{Male,Female,Hermaphrodite}
	private Gender gender;
 	private double weight;
 	private double speed; // speed in place      
	private  Medal [] med;//medal's array
	private int num;//num of way
	public int energy;
	
	protected int size;
	protected Orientation orien; 
	protected int maxEnergy;
	protected int energyPerMeter=2; 
	protected CompetitionPanel pan; 
	protected BufferedImage img1, img2, img3, img4;

	
 	/**
 	 * default constructor
 	 */
	/**
	 * IDrawable's variable
	 */
	
	
public Animal()
{
	super();
	this.name=null;
	this.weight=0;
	this.speed=0;
	this.gender=Gender.Hermaphrodite;
}
/**
 * 
 * constructor
 * 
 * @param location
 * @param name
 * @param weight
 * @param speed 
 * @param g Gender
 */
public Animal(String name,Gender g,double weight,double speed,Point location,int num) 
{
	super(location);
	this.name=name;
	this.weight=weight;
	this.speed=speed;
	this.gender=g;
	this.size=65;
	//this.med= new Medal [m.length];
	//med=m;
	this.orien=Orientation.EAST;
	this.num=num;
	this.maxEnergy=1500;
	this.energy=1500;
	

	
	

	
}
/**
 * 
 * @return name of animal
 */
public String getName() {return this.name;}
/**
 * print name and sound of animal
 */
public void makeSound() 
{
	System.out.println ("Animal: "+ getName()+ " said: " + talk());
}
/**
 * 
 * @return sound of animal
 */
public abstract String talk();

public String toString() {
	String s="\nname: "+this.name
			+"\nGender: "+this.gender
			+"\nweight: "+this.weight
			+"\nspeed: "+this.speed;
			

	//for(int i=0;i<this.med.length;i++)
	//	System.out.print("Medal "+(i+1)+":\n"+med[i].toString());
	return s;
	

	
}
public abstract void loadImages(String nm) throws IOException;
public void setSpeed(double x) {
	this.speed=x;
}
public double getSpeed() {

	return this.speed;
}

 

	/**
	 * Interface IDrawable func
	 */
	public void drawObject (Graphics g) {
		
		 if(orien.equals(Orientation.EAST)) // animal move to the east side
			 g.drawImage(img1,this.getLocation().getX(),this.getLocation().getY()-size/10, size, size,pan);
		else if(orien.equals(Orientation.SOUTH)) // animal move to the south side
			g.drawImage(img2, this.getLocation().getX(), this.getLocation().getY()-size/10, size, size,pan);
		else if(orien.equals(Orientation.WEST)) // animal move to the west side
			g.drawImage(img3, this.getLocation().getX(),this.getLocation().getY()-size/10, size, size,	pan);
		 else if(orien.equals(Orientation.NORTH)) // animal move to the north side
			 g.drawImage(img4, this.getLocation().getX()-size/2, this.getLocation().getY()-size/10, size,size, pan);
		 move();
		}
	int spe=10;
	int maxX=1090;
	int maxY=720;
	int minX=20;
	int minY=20;
	
	public void move() {
	//	 System.out.println("DONE! " + this.energy);
		if(this.energy>0)
		{
		 if(orien.equals(Orientation.EAST))  { // animal move to the east side
			 if (this.getLocation().getX()>=maxX) {
				 this.getLocation().setX(maxX);
				 if(this.getType().equals("Terrestrial"))
					 this.orien= Orientation.SOUTH;
				 
			 	}
			 else
				 this.getLocation().setX(this.getLocation().getX()+(int)speed);
		 }
		 else if(orien.equals(Orientation.SOUTH)) { // animal move to the south side
	
			 if (this.getLocation().getY()>=maxY) {
				 this.getLocation().setY(maxY);
				 this.orien= Orientation.WEST;
			 	}
			 else 
				 this.getLocation().setY(this.getLocation().getY()+(int)speed);
		 }

		else if(orien.equals(Orientation.WEST)){ // animal move to the west side
			 if (this.getLocation().getX()<=minX) {
				 this.getLocation().setX(minX);
				 this.orien= Orientation.NORTH;
			 	}
			 else 
				 this.getLocation().setX( this.getLocation().getX()-(int)speed);
		 }
		 else if(orien.equals(Orientation.NORTH)) { // animal move to the north side
			 if (this.getLocation().getY()<=minY) {
				 this.getLocation().setY(minY);
				this. orien= Orientation.EAST;
			 	} else
				 this.getLocation().setY(this.getLocation().getY()-(int)speed);
		 }
		
	
		}
		
		
		 this.setEnergy(-1);
		this.addTotalDistance(speed);
		
		
	}	
	
	
	
	public boolean eat(int energy) {
		if (this.energy+energy<=this.maxEnergy) {
			this.energy+=energy;
			return true;
		}
		this.energy=this.maxEnergy;
		return false;
			
	}
	public abstract String getCategory();
	public abstract String getType();
	public int getEnergy() {return  this.energy;}
public int getEnergyPerMeter() {return this.energyPerMeter;}
public void  setEnergy (int x) {
	
	this.energy = Math.min(maxEnergy,energy+x);

	
			
}


}
