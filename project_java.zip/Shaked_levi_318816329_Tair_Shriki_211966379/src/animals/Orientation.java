package animals;

public enum Orientation {
	EAST,SOUTH,WEST,NORTH
}
