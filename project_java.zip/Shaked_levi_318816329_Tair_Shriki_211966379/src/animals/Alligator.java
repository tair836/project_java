package animals;
import mobility.Point;

public class Alligator extends WaterAnimal implements IReptile{
	
	private String	AreaOfLiving;
	private TerrestrialAnimals terrestrialAnimals;
	/**
	 * default constructor
	 */
	public Alligator() 
	{
		super();
		System.out.print("Ali");
		this.AreaOfLiving=null;
	}
	/**
	 * constructor
	 * @param area
	 * @param divDept
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Alligator(String area,int noLegs,double divDept,String name,Gender g,double weight,double speed,Point location,int num) 
	{
	
		super(divDept,name,g,weight,speed,location,num);
		terrestrialAnimals= new TerrestrialAnimals(noLegs,name,g,weight,speed,location,num);
		this.AreaOfLiving=area;
	
	}  
	@Override
	public String talk() {return "Roar";}
	
	public String toString() {
		return super.toString()+ "AreaOfLiving:"+this.AreaOfLiving+"\n";
	}
	@Override
	public void speedUp(int x) {
		
		if (x+this.getSpeed()<=this.MAX_SPEED)
			this.setSpeed(x+this.getSpeed());
		
	}
	public String getCategory() {return ("Water"+ "and Terrestrial");}
	public String getType() {return "Alligator";}
}
