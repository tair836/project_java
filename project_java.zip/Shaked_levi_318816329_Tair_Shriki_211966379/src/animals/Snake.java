package animals;

import animals.Animal.Gender;
import mobility.Point;
import olympics.Medal;

public class Snake extends TerrestrialAnimals implements IReptile{
	
	private Poisonous poisonous;
	private double length;
	
	/**
	 * default constructor
	 */
	public Snake() 
	{
		super();
		this.length=0;
		this.poisonous=Poisonous.High;
	}
	/**
	 * constructor
	 * @param len
	 * @param poisonous
	 * @param noLegs
	 * @param location
	 * @param name
	 * @param weight
	 * @param speed
	 * @param g
	 */
	public Snake(Poisonous poi,double len,int noLegs,String name,Gender g,double weight,double speed,Point location,int num)
	{
		super(noLegs,name,g,weight,speed,location,num);
		length=len;
		this.poisonous=poi;
	}
	@Override
	public String talk() {return "ssssssss";}
	
	public String toString() {
		return super.toString()+"\n"+"Poisonous: "+this.poisonous+"\nLength: "+this.length+"\n";
	}
	@Override
	public void speedUp(int x) {
		double temp= x+this.getSpeed();
		if (temp<=this.MAX_SPEED)
			this.setSpeed(temp);
		
	}
	public String getType() {return "Snake";}
}
