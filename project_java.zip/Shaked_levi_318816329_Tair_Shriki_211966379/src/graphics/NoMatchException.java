package graphics;

class NoMatchException extends Exception {
    public NoMatchException(String message){
        super(message);
    }
}

