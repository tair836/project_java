 package graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import animals.Alligator;
import animals.Animal;
import animals.Cat;
import animals.Dog;
import animals.Dolphin;
import animals.Eagle;
import animals.Pigeon;
import animals.Poisonous;
import animals.Snake;
import animals.WaterType;
import animals.Whale;
import animals.Animal.Gender;
import mobility.Point;



public class AddAnimalDialog  implements ActionListener {
	
	 public static BufferedImage image1;
	 static JFrame frame;
	 static JPanel panel;
	JLabel label;
	public  Animal ani=null;


	static ButtonGroup group= new ButtonGroup();
	
 static JRadioButton pigeon,eagle,dog,cat,snake,alligator,alligator2,whale,dolphin;// all the animals 
 JRadioButton hermaphrodite1,male1,femal1;
 JLabel name1,weight1,speed1,energyPerMeter1,gender1,num1;
 JTextField name2,weight2,speed2,energyPerMeter2,num2;
	 
	JButton button,button1,comp1,comp2,comp3;
	String input;
	ButtonGroup g ;
	
	
	String	name ;//animal's name 
	Gender gn = null;
 	double weight = 0,speed = 0;
	//Medal [] m;
	 int energyPerMeter,num = 0;
	 Point location =new Point(0,0);
	
//Air fields ------------------------------------------------------------------------------------------------------------------------------------
	 double	altitudeOfFlight;//eagle air
	 String family;//pigeon air
	 double wingspan;//air animal 
	
//Water fields -------------------------------------------------------------------------------------------------------------------------------------
	 String	AreaOfLiving;//alligator 
	 WaterType water=null;//dolpine enum
	 double diveDept ;//water
	 String foodType;//whale 
	 
	 
//Terrestrial fields -------------------------------------------------------------------------------------------------------------------------------
	// String	AreaOfLiving;//alligator
	 boolean Castrated;//cat terrestrial
	 String breed;//dog
	 Poisonous poisonous = null;// snake enum
	 double length;//snake
	 int noLegs;//legs' number
	 
	 /**
	  * choose animal from list of all animal in this competition.
	  * @param n input of type competition
	  */
	public void AddAnimalDialog1(String n)  {//show all the animal 

		/*list of animals to add*/
		g= new ButtonGroup();
		input=n;
		frame= new JFrame("AddAnimalDialog");
		
		panel =new JPanel( );
		frame.add(panel);
		panel.setLayout(null);
		panel.setSize(500, 500);
		
		label = new JLabel("TerretrialAnimal:"); 
		label.setBounds(50, 20, 100, 80);
		panel.add(label);
		
		dog = new JRadioButton("Dog"); 
		dog.setMnemonic(KeyEvent.VK_C); 
		dog.setVisible(true);
		dog.setSelected(false); 
		dog.setBounds(50,100,150,150);
		panel.add(dog);
		
		cat = new JRadioButton("Cat"); 
		cat.setMnemonic(KeyEvent.VK_C); 
		cat.setVisible(true);
		cat.setSelected(false); 
		cat.setBounds(50,200,150,150);
		panel.add(cat);
		
		snake = new JRadioButton("Snake"); 
		snake.setMnemonic(KeyEvent.VK_C); 
		snake.setVisible(true);
		snake.setSelected(false); 
		snake.setBounds(50,300,150,150);
		panel.add(snake);
		
		alligator = new JRadioButton("Alligator"); 
		alligator.setMnemonic(KeyEvent.VK_C); 
		alligator.setVisible(true);
		alligator.setSelected(false); 
		alligator.setBounds(50,400,150,150);
		panel.add(alligator);
		
		label = new JLabel("WaterAnimal:"); 
		label.setBounds(200, 20, 100, 80);
		panel.add(label);
		
		alligator2 = new JRadioButton("Alligator"); 
		alligator2.setMnemonic(KeyEvent.VK_C); 
		alligator2.setVisible(true);
		alligator2.setSelected(false); 
		alligator2.setBounds(200,100,150,150);
		panel.add(alligator2);
		
		whale = new JRadioButton("Whale"); 
		whale.setMnemonic(KeyEvent.VK_C); 
		whale.setVisible(true);
		whale.setSelected(false); 
		whale.setBounds(200, 200, 150, 150);
		panel.add(whale);
		

		dolphin = new JRadioButton("Dolphin"); 
		dolphin.setMnemonic(KeyEvent.VK_C); 
		dolphin.setVisible(true);
		dolphin.setSelected(false); 
		dolphin.setBounds(200, 300, 150, 150);
		panel.add(dolphin);
		
		label = new JLabel("AirAnimal:"); 
		label.setBounds(350, 20, 100, 80);
		panel.add(label);
		
		pigeon = new JRadioButton("Pigeon"); 
		pigeon.setMnemonic(KeyEvent.VK_C); 
		pigeon.setVisible(true);
		pigeon.setSelected(false); 
		pigeon.setBounds(350, 100, 150, 150);
		panel.add(pigeon);
		
		eagle = new JRadioButton("Eagle"); 
		eagle.setMnemonic(KeyEvent.VK_C); 
		eagle.setVisible(true);
		eagle.setSelected(false); 
		eagle.setBounds(350, 200, 150, 150);
		panel.add(eagle);
		
		g.add(pigeon);
		g.add(dog);
		g.add(whale);
		g.add(dolphin);
		g.add(snake);
		g.add(eagle);
		g.add(cat);
		g.add(alligator);
		g.add(alligator2);
	
		button = new JButton("OK");
		button.setBounds(200,500,80,30);
		button.addActionListener(this); 
		
		panel.add(button);
		frame.add(panel);
		frame.setSize(630, 630);
		frame.setVisible(true);

	}
	public void setNname(String w) {
		this.name=w;
	}

	/**
	 * add animal according input.
	 */
	public void actionPerformed(ActionEvent e) {//checking the buttons
		
		String x=e.getActionCommand();
		if(x.contentEquals("OK")) {
		if(input.equals("Air")) {
		
			if((eagle.isSelected())) {
				addAnimal();
				
			}
				else if(pigeon.isSelected()) {
					addAnimal();
					
				}
			
			else {
				JOptionPane.showMessageDialog(null, "Your animal is not suitable for competition", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		else if(input.equals("Water")) {
			
			if ((whale.isSelected()||dolphin.isSelected()||alligator2.isSelected())) {
				addAnimal();
			}
			else {
				JOptionPane.showMessageDialog(null, "Your animal is not suitable for competition", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		else if(input.equals("Terrestrial")) {
			
			if ((alligator.isSelected()|| cat.isSelected()|| dog.isSelected()||snake.isSelected())) {
				
				addAnimal();}
			else {
				JOptionPane.showMessageDialog(null, "Your animal is not suitable for competition", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			
		}
		}
		
		
		else if(x.contentEquals("Create Animal")){//Create Animal
			
			setNname(name2.getText());
      		speed= new Double(speed2.getText());
      		weight= Double.parseDouble(weight2.getText());
      		energyPerMeter= new Integer(energyPerMeter2.getText());
      		if(femal1.isSelected()) 
     			gn =Gender.Female;
     		
     		else if(male1.isSelected()) 
     			gn=Gender.Male;
     		else 
     			gn=Gender.Hermaphrodite;
      		
      		num= new Integer (num2.getText()); 

         	 ani=new Eagle(1.2,wingspan, name, gn,12.9, speed, new Point (num,0), num);
         	 
         	frame.setVisible(false);
         	
        	if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
			{
    			
    			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
    		
    			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
     			if(CompetitionFrame.j==0)
     				CompetitionFrame.i++;
			}

      
		}
		
	}
	

//All the fields of the animal-----------------------------------------------------------------------------------------------------	
	public void addAnimal() {//enter all the vars of class animal and
	

		frame.setVisible(false);
		frame= new JFrame("Fill the fields");
		panel = new JPanel();

		
		panel.setLayout(null);
		frame.add(panel);
		
		   
    	comp1 = new JButton("Group1");
    	comp1.setBounds(50, 438, 150, 40);
           comp1.addActionListener( 
            		new ActionListener()
            {
            @Override
               public void actionPerformed(ActionEvent event)
               {CompetitionFrame.i=0; }});
            panel.add(comp1);
            
        comp2 = new JButton("Group2");
        comp2.setBounds(210, 438, 150, 40);
        comp2.addActionListener( 
              new ActionListener()
                {
                @Override
                   public void actionPerformed(ActionEvent event)
                   {CompetitionFrame.i=1;}});
                panel.add(comp2); 
               
        comp3 = new JButton("Group3");
        comp3.setBounds(370, 438, 150, 40);
        comp3.addActionListener( 
             new ActionListener()
              {
                @Override
              public void actionPerformed(ActionEvent event)
                {CompetitionFrame.i=2;}});
               panel.add(comp3);
            

		name1= new JLabel("Name");
		name1.setBounds(10, 20, 60, 25);
		panel.add(name1);
		
		name2= new JTextField();
		name2.setBounds(150, 20, 80, 25);
		panel.add(name2);

		
		weight1=new JLabel ("Weight");
		weight1.setBounds(10, 70, 80, 25);
		
		panel.add(weight1);
		
		weight2= new JTextField();
		weight2.setBounds(150,70, 80, 25);
		panel.add(weight2);
	
		
		speed1=new JLabel ("Speed");
		speed1.setBounds(10, 120, 80, 25);
		panel.add(speed1);
		
		speed2= new JTextField();
		speed2.setBounds(150, 120, 80, 25);
		panel.add(speed2);
		
		
		energyPerMeter1=new JLabel ("EnergyPerMeter");
		energyPerMeter1.setBounds(10, 170, 100, 25);
		panel.add(energyPerMeter1);
		
		energyPerMeter2= new JTextField();
		energyPerMeter2.setBounds(150, 170, 80, 25);
		panel.add(energyPerMeter2);
	
		
		
		//Gender
		gender1=new JLabel ("Gender");
		gender1.setBounds(10, 220, 100, 25);
		panel.add(gender1);
		
		male1= new JRadioButton ("Male");
		male1.setBounds(150, 220, 80, 25);
		male1.setVisible(true);
		male1.setSelected(false);
		panel.add(male1);
		hermaphrodite1= new JRadioButton ("Hermaphrodite");
		hermaphrodite1.setBounds(230, 220, 167, 25);
		hermaphrodite1.setVisible(true);
		hermaphrodite1.setSelected(false);
		panel.add(hermaphrodite1);
		femal1= new JRadioButton ("Femal");
		femal1.setBounds(395, 220, 80, 25);
		femal1.setVisible(true);
		femal1.setSelected(false);
		panel.add(femal1);
		group.add(femal1);
		group.add(male1);
		group.add(hermaphrodite1);
	
		
		
				
		// medals
//Air Animal -----------------------------------------------------------------------------------------------------------------------		
		if (input.equals("Air")) {
			
			num1= new JLabel("Route");
			num1.setBounds(10, 270, 60, 25);
			panel.add(num1);
			
			num2= new JTextField();
			num2.setBounds(150,270, 80, 25);
			panel.add(num2);
			
			JLabel wingspan1,altitudeOfFlight1,family1;
			JTextField wingspan2,altitudeOfFlight2,family2;
		

			wingspan1=new JLabel ("Wingspan");
			wingspan1.setBounds(10, 320, 80, 25);
			panel.add(wingspan1);
			
			wingspan2= new JTextField();
			wingspan2.setBounds(150, 320, 80, 25);
			panel.add(wingspan2);
			
			
			//Eagle -------------------------------------------------------------------------------------------------------
			if (eagle.isSelected()) {
				
				altitudeOfFlight1= new JLabel("AltitudeOfFlight");
				altitudeOfFlight1.setBounds(10, 370, 80, 25);
				
				panel.add(altitudeOfFlight1);
				
				altitudeOfFlight2= new JTextField();
				altitudeOfFlight2.setBounds(150, 370, 80, 25);
				panel.add(altitudeOfFlight2);
				
				
				button1 = new JButton("Create Animal");
				button1.setBounds(200,500,300,30);
				button1.addActionListener(this);			
				panel.add(button1);
			
				 
			}
		//Pigeon --------------------------------------------------------------------------------------------------------------------------
			else {//(pigeon.isSelected()) {
				
				family1= new JLabel("Family");
				family1.setBounds(10, 370, 80, 25);
				panel.add(family1);
				
				family2= new JTextField();
				family2.setBounds(150, 370, 80, 25);
				panel.add(family2);
				
				
				button1 = new JButton("Create Animal");
				button1.setBounds(200,500,300,30);
				button1.addActionListener(
		                 new ActionListener()
		                 {
		                 @Override
		                    public void actionPerformed(ActionEvent event)
		                    {
		                    
			                	 
		                	 setNname(name2.getText());
		                	
			             		speed= new Double(speed2.getText());
			             		weight= Double.parseDouble(weight2.getText());
			             		energyPerMeter= Integer.parseInt(energyPerMeter2.getText());
			             		if(femal1.isSelected()) 
			            			gn =Gender.Female;
			            		
			            		else if(male1.isSelected()) 
			            			gn=Gender.Male;
			            		else 
			            			gn=Gender.Hermaphrodite;
			             		
			             		wingspan = Double.parseDouble((wingspan2.getText()));
			             		family = family2.getText();
			             		num=  Integer.parseInt(num2.getText());
		                	
		                	 ani=new Pigeon( family,wingspan,name,gn,weight,speed, new Point(num,0),num);
		                	 frame.setVisible(false);
		                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
		         			{
		             			
		             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
		             		
		             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
		             			if(CompetitionFrame.j==0)
		             				CompetitionFrame.i++;
		         			}
		                	
		                    }
		                 }
		                 );
			
				
				panel.add(button1);
		
			}	
		}
//Water Animal -----------------------------------------------------------------------------------------------------------------------
		else if (input.equals("Water")) {
			
			JLabel diveDept1,foodType1,AreaOfLiving1,water1;
			JTextField diveDept2,foodType2,AreaOfLiving2;
			JRadioButton sea, sweet;
			 
			 
			 diveDept1=new JLabel ("DiveDept");
			 diveDept1.setBounds(10, 270, 80, 25);
			 panel.add(diveDept1);
				
				diveDept2= new JTextField();
				diveDept2.setBounds(150, 270, 80, 25);
				panel.add(diveDept2);
				
		//Alligator-----------------------------------------------------------------------------------------------------		
				if (alligator2.isSelected()) {
					
					AreaOfLiving1= new JLabel("AreaOfLiving");
					AreaOfLiving1.setBounds(10, 320, 80, 25);
					panel.add(AreaOfLiving1);
					
					AreaOfLiving2= new JTextField();
					AreaOfLiving2.setBounds(150, 320, 80, 25);
					panel.add(AreaOfLiving2);
					
					 JLabel noLegs1 = new JLabel ("NoLegs");
    				 noLegs1.setBounds(10, 370, 80, 25);
    				 panel.add(noLegs1);
    					
    					JTextField noLegs2 = new JTextField();
    					noLegs2.setBounds(150, 370, 80, 25);
    					panel.add(noLegs2);
    					
    					
					button1 = new JButton("Create Animal");
					button1.setBounds(200,520,300,30);
					button1.addActionListener(
			                 new ActionListener()
			                 {
			                 @Override
			                    public void actionPerformed(ActionEvent event)
			                    {

			                	 name= name2.getText();
			             		speed= new Double(speed2.getText());
			             		weight= Double.parseDouble(weight2.getText());
			             		energyPerMeter= new Integer(energyPerMeter2.getText());
			             		if(femal1.isSelected()) 
			            			gn =Gender.Female;
			            		
			            		else if(male1.isSelected()) 
			            			gn=Gender.Male;
			            		else 
			            			gn=Gender.Hermaphrodite;
			             		
			             		diveDept=Double.parseDouble(diveDept2.getText());
			    					noLegs= Integer.valueOf((noLegs2.getText()));
			    					AreaOfLiving= AreaOfLiving2.getText();
			           
			                	 ani=new Alligator( AreaOfLiving, noLegs, diveDept, name, gn, weight,speed,new Point (num,120),0); 
			                	
			                	 frame.setVisible(false);
			                	 
			                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
			         			{
			             			
			             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
			             		
			             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
			             			if(CompetitionFrame.j==0)
			             				CompetitionFrame.i++;			         			}
			                	 
			                    }
			                 }
			                 );
					
					panel.add(button1);
					
					 
				}
			//Dolphin -------------------------------------------------------------------------------------------------------------
				else if(dolphin.isSelected()) {
					
					water1= new JLabel("Water");
					water1.setBounds(10, 320, 80, 25);
					panel.add(water1);
					
					
					sea= new JRadioButton ("Sea");
					sea.setBounds(100, 320, 100, 25);
					sea.setVisible(true);
					sea.setSelected(false);
					
					sweet= new JRadioButton ("Sweet");
					sweet.setBounds(200, 320, 80, 25);
					sweet.setVisible(true);
					sweet.setSelected(false);
					panel.add(sea);
					panel.add(sweet);
					g.add(sea);
					g.add(sweet);
					
					if(sweet.isSelected()) 
						water =WaterType.Sweet;
					
					else if(sea.isSelected()) 
						water=WaterType.Sea;
					
					button1 = new JButton("Create Animal");
					button1.setBounds(200,500,300,30);
					button1.addActionListener(
			                 new ActionListener()
			                 {
			                 @Override
			                    public void actionPerformed(ActionEvent event)
			                    {
			                  	 name= name2.getText();
				             		speed= new Double(speed2.getText());
				             		weight= Double.parseDouble(weight2.getText());
				             		energyPerMeter= new Integer(energyPerMeter2.getText());
				             		if(femal1.isSelected()) 
				            			gn =Gender.Female;
				            		
				            		else if(male1.isSelected()) 
				            			gn=Gender.Male;
				            		else 
				            			gn=Gender.Hermaphrodite;
				             		diveDept=Double.parseDouble(diveDept2.getText());				             		
				             		if(sweet.isSelected()) 
										water =WaterType.Sweet;
									
									else if(sea.isSelected()) 
										water=WaterType.Sea;
				             		
				             	
			                	 ani=new Dolphin( water, diveDept, name, gn, weight, speed,new Point(num,120),num);
			                	 
			                	 
			                	 frame.setVisible(false);
			               
			                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
			         			{
			             			
			             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
			             		
			             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
			             			if(CompetitionFrame.j==0)
			             				CompetitionFrame.i++;		         			}

			                    }
			                 }
			                 );
					panel.add(button1);
					
						
				
				}
				//Whale ----------------------------------------------------------------------------------------------------------------
				else {//(whale.isSelected()) 
					
					foodType1= new JLabel("FoodType");
					foodType1.setBounds(10, 320, 80, 25);
					panel.add(foodType1);
					
					foodType2= new JTextField();
					foodType2.setBounds(150, 320, 80, 25);
					panel.add(foodType2);
					foodType = foodType2.getText();
					
					button1 = new JButton("Create Animal");
					button1.setBounds(200,500,300,30);
					button1.addActionListener(
			                 new ActionListener()
			                 {
			                 @Override
			                    public void actionPerformed(ActionEvent event)
			                    {
			                  	 name= name2.getText();
				             		speed= new Double(speed2.getText());
				             		weight= Double.parseDouble(weight2.getText());
				             		energyPerMeter= new Integer(energyPerMeter2.getText());
				             		if(femal1.isSelected()) 
				            			gn =Gender.Female;
				            		
				            		else if(male1.isSelected()) 
				            			gn=Gender.Male;
				            		else 
				            			gn=Gender.Hermaphrodite;
				             		diveDept=Double.parseDouble(diveDept2.getText());
				             		foodType = foodType2.getText();
			                	 ani=new Whale(foodType, diveDept, name, gn, weight, speed,new Point(num,120), num);
			                
			                	 frame.setVisible(false);
			                	 
			                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
			         			{
			             			
			             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
			             		
			             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
			             			if(CompetitionFrame.j==0)
			             				CompetitionFrame.i++;			         			}
			                	

			                    }
			                 }
			                 );
					panel.add(button1);

				}
		}
//Terrestrial Animal ----------------------------------------------------------------------------------------------------
		else if (input.equals("Terrestrial")){
			
			
				JLabel noLegs1,breed1,AreaOfLiving1,Castrated1,poisonous1,diveDept1;
				JTextField noLegs2,breed2,AreaOfLiving2,diveDept2;
			
				JRadioButton no1,yes1,High1,Medium1,Low1;
				 
				 
				  noLegs1=new JLabel ("NoLegs");
				 noLegs1.setBounds(10, 270, 80, 25);
				 panel.add(noLegs1);
					
					noLegs2= new JTextField();
					noLegs2.setBounds(150, 270, 80, 25);
					panel.add(noLegs2);
				//Alligator -------------------------------------------------------------------------------------------------------	
					if (alligator.isSelected()) {
						
						 diveDept1=new JLabel ("DiveDept");
						 diveDept1.setBounds(10, 320, 80, 25);
						 panel.add(diveDept1);
							
							diveDept2= new JTextField();
							diveDept2.setBounds(150, 320, 80, 25);
							panel.add(diveDept2);
						
						AreaOfLiving1= new JLabel("AreaOfLiving");
						AreaOfLiving1.setBounds(10, 370, 80, 25);
						panel.add(AreaOfLiving1);
						
						AreaOfLiving2= new JTextField();
						AreaOfLiving2.setBounds(150, 370, 80, 25);
						panel.add(AreaOfLiving2);
						
						button1 = new JButton("Create Animal");
						button1.setBounds(200,520,300,30);
						button1.addActionListener(
				                 new ActionListener()
				                 {
				                 @Override
				                    public void actionPerformed(ActionEvent event)
				                    {

				                	name= name2.getText();
				             		speed= new Double(speed2.getText());
				             		weight= Double.parseDouble(weight2.getText());
				             		energyPerMeter= new Integer(energyPerMeter2.getText());
				             		if(femal1.isSelected()) 
				            			gn =Gender.Female;
				            		
				            		else if(male1.isSelected()) 
				            			gn=Gender.Male;
				            		else 
				            			gn=Gender.Hermaphrodite;
				             		
				             			diveDept=Double.parseDouble(diveDept2.getText());
				    					noLegs= Integer.valueOf((noLegs2.getText()));
				    					AreaOfLiving= AreaOfLiving2.getText();
				           
				                	 ani=new Alligator( AreaOfLiving, noLegs, diveDept, name, gn, weight,speed,new Point (num,0),0); 
				                	
				                	 frame.setVisible(false);
				                	 
				                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
				         			{
				             			
				             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
				             		
				             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
				             			if(CompetitionFrame.j==0)
				             				CompetitionFrame.i++;				         			}
				                    }
				                 }
				                 );
						
						panel.add(button1);
						
			//Cat ----------------------------------------------------------------------------------------------------------------------------------
					}
					else if(cat.isSelected()) {
						
						Castrated1= new JLabel("Castrated");
						Castrated1.setBounds(10, 320, 80, 25);
						panel.add(Castrated1);
						
						no1= new JRadioButton ("No");
						no1.setBounds(100, 320, 167, 25);
						no1.setVisible(true);
						no1.setSelected(false);
						panel.add(no1);
						yes1= new JRadioButton ("Yes");
						yes1.setBounds(380, 320, 80, 25);
						yes1.setVisible(true);
						yes1.setSelected(false);
						panel.add(yes1);
						g.add(yes1);
						g.add(no1);
						
						if(yes1.isSelected()) 
							Castrated =true;
						
						else if(no1.isSelected()) 
							Castrated =false;
						
						button1 = new JButton("Create Animal");
						button1.setBounds(200,500,300,30);
						button1.addActionListener(
				                 new ActionListener()
				                 {
				                 @Override
				                    public void actionPerformed(ActionEvent event)
				                    {
				                	 name= name2.getText();
					             		speed= new Double(speed2.getText());
					             		weight= Double.parseDouble(weight2.getText());
					             		energyPerMeter= new Integer(energyPerMeter2.getText());
					             		if(femal1.isSelected()) 
					            			gn =Gender.Female;
					            		
					            		else if(male1.isSelected()) 
					            			gn=Gender.Male;
					            		else 
					            			gn=Gender.Hermaphrodite;
					             		
					    					noLegs= Integer.valueOf((noLegs2.getText()));
					           
					                	 ani=new Cat(Castrated, noLegs, name, gn, weight,speed,new Point (num,0),0); 
					                	
					                	 frame.setVisible(false);
					                	 
					                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
					         			{
					             			
					             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
					             		
					             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
					             			if(CompetitionFrame.j==0)
					             				CompetitionFrame.i++;					         			}
				                    }
				                 }
				                 );
						panel.add(button1);
						
							
						
					}
			//Dog --------------------------------------------------------------------------------------------------------------------------		
					else if(dog.isSelected()) {
						
						breed1= new JLabel("Breed");
						breed1.setBounds(10, 320, 80, 25);
						panel.add(breed1);
						
						breed2= new JTextField();
						breed2.setBounds(150, 320, 80, 25);
						panel.add(breed2);
						breed = breed2.getText();
						
						button1 = new JButton("Create Animal");
						button1.setBounds(200,500,300,30);
						button1.addActionListener(
				                 new ActionListener()
				                 {
				                 @Override
				                    public void actionPerformed(ActionEvent event)
				                    {
				                	
				                	 name= name2.getText();
					             		speed= new Double(speed2.getText());
					             		weight= Double.parseDouble(weight2.getText());
					             		energyPerMeter= new Integer(energyPerMeter2.getText());
					             		if(femal1.isSelected()) 
					            			gn =Gender.Female;
					            		
					            		else if(male1.isSelected()) 
					            			gn=Gender.Male;
					            		else 
					            			gn=Gender.Hermaphrodite;
					             		
					    					noLegs= Integer.valueOf((noLegs2.getText()));
					           
					                	 ani=new Dog(breed, noLegs, name, gn, weight,speed,new Point (num,0),0); 
					                	
					                	 frame.setVisible(false);
					                	 
					                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
					         			{
					             			
					             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;
					             		
					             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
					             			if(CompetitionFrame.j==0)
					             				CompetitionFrame.i++;
					             			}

				                    }
				                 }
				                 );
						panel.add(button1);
					//Snake ------------------------------------------------------------------------------------------------------------						
					}
					else {// snake.isSlected()
						
						poisonous1=new JLabel ("Poisonous");
						poisonous1.setBounds(10, 320, 100, 25);
						panel.add(poisonous1);
						
						High1= new JRadioButton ("High");
						High1.setBounds(150, 320, 80, 25);
						High1.setVisible(true);
						High1.setSelected(false);
						panel.add(High1);
						Low1= new JRadioButton ("Low");
						Low1.setBounds(230, 320, 80, 25);
						Low1.setVisible(true);
						Low1.setSelected(false);
						panel.add(Low1);
						Medium1= new JRadioButton ("Medium");
						Medium1.setBounds(380,320, 80, 25);
						Medium1.setVisible(true);
						Medium1.setSelected(false);
						panel.add(Medium1);
						g.add(High1);
						g.add(Low1);
						g.add(Medium1);
						if(Medium1.isSelected()) 
							poisonous= Poisonous.Medium;
						
						else if(Low1.isSelected()) 
							poisonous= Poisonous.Low;
						else 
							poisonous= Poisonous.High;
						
						JLabel length1 = new JLabel("length");
						length1.setBounds(10, 370, 80, 25);
						panel.add(length1);
						
						JTextField length2 = new JTextField();
						length2.setBounds(150,370, 80, 25);
						panel.add(length2);
						
						button1 = new JButton("Create Animal");
						button1.setBounds(200,500,300,30);
						button1.addActionListener(
				                 new ActionListener()
				                 {
				                 @Override
				                    public void actionPerformed(ActionEvent event)
				                    {
				                	 name= name2.getText();
					             		speed= new Double(speed2.getText());
					             		weight= Double.parseDouble(weight2.getText());
					             		energyPerMeter= new Integer(energyPerMeter2.getText());
										length = Double.parseDouble(length2.getText());

					             		if(femal1.isSelected()) 
					            			gn =Gender.Female;
					            		
					            		else if(male1.isSelected()) 
					            			gn=Gender.Male;
					            		else 
					            			gn=Gender.Hermaphrodite;
					             		
					    					noLegs= Integer.valueOf((noLegs2.getText()));
					           
					    					ani=new Snake(poisonous,length, noLegs, name, gn, weight,speed,new Point (num,0),0);
											
					                	
					                	 frame.setVisible(false);
					                	 
					                	 if( CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]==null)
					         			{					             			
					             			CompetitionFrame.ani_arr[CompetitionFrame.i][CompetitionFrame.j]=ani;					             		
					             			CompetitionFrame.j=(1+CompetitionFrame.j )%3;
					             			if(CompetitionFrame.j==0)
					             				CompetitionFrame.i++;					         			}
				                    }
				                 } );						 
						panel.add(button1);
					}		
		}
		frame.setSize(630, 630);
		frame.setVisible(true);
		}
}