package graphics;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class info {
	/**
	 * show info of all animals in this competitor.
	 */
	public info() {
	JFrame fram=new JFrame("Information Table");
	 JTable table=null;
	 
	 String [] columnNames= {"Animal","Category","Type","Speed","Energy Amaunt","Distance","Energy Comsumpt"};
	 Object [][] data=new Object[CompetitionFrame.i][7];
	 for(int i=0;i<CompetitionFrame.i+1;++i) {
		 for(int j=0;j<CompetitionFrame.j;++j) {

			data[i][0]=CompetitionFrame.ani_arr[i][j].getName(); 
			data[i][1]=CompetitionFrame.ani_arr[i][j].getCategory();
			data[i][2]=CompetitionFrame.ani_arr[i][j].getType();
			data[i][3]=CompetitionFrame.ani_arr[i][j].getSpeed();
			data[i][4]=CompetitionFrame.ani_arr[i][j].getEnergy();
			data[i][5]=CompetitionFrame.ani_arr[i][j].getTotalDistance();
			data[i][6]=CompetitionFrame.ani_arr[i][j].getType();
			//data[i][6]=CompetitionFrame.i;
		 }
    
	 }
	 
	 
     table=new JTable(data,columnNames);  		      
     table.setBounds(100,100,200,300); 
     JScrollPane sp=new JScrollPane(table); 
     fram.add(sp);         
     fram.setSize(850,200);    
     fram.setVisible(true);
	}
}


