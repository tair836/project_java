package olympics;

public enum MedalType {
 
	BRONZE,SILVER,GOLD
}
