package mobility;

public interface ILocatable {
	/**
	 * interface
	 *
	 */

	public Point getLocation();
	public boolean setLocation(Point p);

}
