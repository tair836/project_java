package tournament;

public class Boolean {
	
	private boolean state;
	public Boolean(boolean state) {
		this.state=state;
	}
	
	public boolean getBoolean() {
		return this.state;
	}
	public void  setBoolean(boolean state) {
		this.state=state;
	}
	public String toString() {if (state==(false)) return "false";return "true";}

}
