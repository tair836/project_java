package tournament;

public class Referee implements Runnable {
	
	private String name=null;
	private Scores scores;
	
	/**
	 * cons
	 * @param name
	 * @param scores
	 * @param finishFlag
	 */
	public static Referee referee=null;
	
	public static Referee getInstance(String name,Scores scores,Boolean finishFlag) {
		
		if (referee==null)
			referee=new Referee(name,scores,finishFlag);
		return referee;
	}
	
	private  Referee(String name,Scores scores,Boolean finishFlag)
	{
		this.name=name;
		this.scores=scores;
	}
	public Referee() {}

	
	/**
	 * need to wait to animal.whem the animal came the fun need to send to scores.add(name).
	 */
	@Override
	public void run() {
		
		synchronized(this) {//q or this or this.score
			while(this.name == null) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			
			}
			
			scores.add(name);
			notify();
		}	
	}

}
